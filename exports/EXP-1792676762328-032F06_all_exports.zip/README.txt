Revenue Intelligence Inbox - Export Package
==================================================
Export ID: EXP-1792676762328-032F06
Export Date: 2026-10-22T13:46:02.328Z
Application Version: 1.0.0
Schema Version: 1.4.0
Rule Version: v1.4.0-composite

Contents:
- conversations.csv: Exported conversations (0 records)
- conversations.json: Complete structured metadata and transcripts
- routing_audit.csv: Explainable queue decisions and score breakdowns
- follow_up_actions.csv: Active commitments and action items
- import_summary.csv: Provenance and batch duplicate/update statistics
- corrections_audit.csv: Human-in-the-loop manual override history
- findings.json: Executive insights and documented rejected decisions
- manifest.json: Verified SHA-256 checksums and filter criteria

Filters Applied:
{}
